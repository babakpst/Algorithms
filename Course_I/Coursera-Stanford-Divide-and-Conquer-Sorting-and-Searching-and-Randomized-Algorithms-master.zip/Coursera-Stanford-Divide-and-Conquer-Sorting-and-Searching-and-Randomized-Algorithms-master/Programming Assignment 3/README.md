# Goal
- QuickSort the the array 
- compute the total number of comparisions 
# File Description
- `.txt` files is data file.
  - `QuickSort.txt` consists of 10,000 integers.
- `.py` file is the solution of Week 3 program assignment
  - `QuickSort.py`

# Algorithm
- QuickSort [reference 1](https://github.com/SSQ/Coursera-Stanford-Divide-and-Conquer-Sorting-and-Searching-and-Randomized-Algorithms/blob/master/Lecture%20Slides/5.1-slides_algo-qsort-intro_typed.pdf), [reference 2](https://github.com/SSQ/Coursera-Stanford-Divide-and-Conquer-Sorting-and-Searching-and-Randomized-Algorithms/blob/master/Lecture%20Slides/5.2-slides_algo-qsort-partition_typed.pdf).
# Implementation
1. First pivot
2. Last pivot
3. Medium pivot
