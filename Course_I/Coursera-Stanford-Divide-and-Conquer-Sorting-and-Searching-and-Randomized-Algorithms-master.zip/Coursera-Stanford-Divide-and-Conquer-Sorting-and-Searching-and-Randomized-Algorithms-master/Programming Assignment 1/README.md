# File Description
  - `.py` file is the solution of Week 1 program assignment
    - `karatsuba.py`
# Implementation
  - [Karatsuba Multiplication](https://github.com/SSQ/Coursera-Stanford-Divide-and-Conquer-Sorting-and-Searching-and-Randomized-Algorithms/blob/master/Lecture%20Slides/1.3-algo1-intro3_typed.pdf)
